<?php get_header();?>
<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block">
			<div id="main-content" class="col-2-3">
				<div class="wrap-col">
				<?php while(have_posts()):the_post();?>
					<article>
						<div class="heading">
							<h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
							<div class="info">By <?php the_author();?> on <?php the_date('')?> with <a href="#">01 Commnets</a></div>
						</div>
						<div class="content">
							<?php the_post_thumbnail();?>
							<p><?php the_content();?></p>
							<?php comments_template();?>
						</div>
					</article>
				<?php endwhile;?>						 				
				</div>
			</div>
			<div id="sidebar" class="col-1-3">
				<?php dynamic_sidebar('ls');?>
			</div>
		</div>
	</div>
</section>
<!--------------Footer--------------->
<?php get_footer();?>
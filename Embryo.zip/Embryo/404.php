<?php get_header();?>
<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block">
			<div id="main-content" class="col-2-3">
				<div class="wrap-col">
 					<article>
						<div class="heading">
							<h2>Page not found!!!</h2>
 						</div>
					</article>					
				</div>
			</div>
			<div id="sidebar" class="col-1-3">
				<?php dynamic_sidebar('ls');?>
			</div>
		</div>
	</div>
</section>
<!--------------Footer--------------->
<?php get_footer();?>
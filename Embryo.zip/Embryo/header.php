<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

    <!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
 	<meta name="description" content="Free Html5 Templates and Free Responsive Themes Designed by Kimmy | zerotheme.com">
	<meta name="author" content="www.zerotheme.com">
	
    <!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
 
    <?php wp_head();?>
</head>
<body <?php body_class();?>>
<!--------------Header--------------->
<header>
	<div class="wrap-header zerogrid">
		<div id="logo">
			<a href="<?php bloginfo('home');?>">
				<?php
					$logo = new WP_query(array(
						'post_type'=>'logo',
						'posts_per_page'=>1
					));
				?>
				<?php while($logo->have_posts()):$logo->the_post();?>
					<?php the_post_thumbnail();?>
				<?php endwhile;?>
			</a>
		</div>
		<nav>
			<div class="wrap-nav">
				<div class="menu">
				    <?php 
						wp_nav_menu(array(
							'theme_location'=>'primary',
							'fallback_cb'=>'default_menu',
							'container'=>' ', 
						));
					?>
				</div>
			</div>
		</nav>
	</div>
</header>
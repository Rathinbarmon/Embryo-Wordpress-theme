<?php 

//After theme set up

function embryo_setup(){
	
	load_theme_textdomain( 'embryo', get_template_directory() . '/languages/' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'custom-background' );
	add_theme_support( 'post-thumbnails' ); 
    add_image_size('about',300,300,true);
	
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'embryo' ), 
	));
	
	add_theme_support( 'post-formats', array(
		'aside', 'image','audio','video', 'quote', 'link', 'gallery', 'status',  'chat'
	) );
}
add_action( 'after_setup_theme', 'embryo_setup' );

// Default menu setup
 
function default_menu(){
	
	echo'<ul>';
	if(is_user_logged_in()){
		echo'<li><a href="'.home_url().'/wp-admin/nav-menus.php"> Create Your Menu </a></li>';
	}
	else{ 
		echo'<li><a href="'.home_url().'"> Home </a></li>';
	}
	echo'</ul>';
}

//custom post register
function embryo_custom_post(){ 

	register_post_type('logo',array(
	   'labels'=>array(
			'name'=>__('Upload Logo','embryo')
	   ),  
	   'supports'=>array('thumbnail'),
	   'public'=>true,	   
	));
	
	register_post_type('cp',array(
	   'labels'=>array(
			'name'=>__('Copyright Text','embryo')
	   ),  
	   'supports'=>array('title','editor'),
	   'public'=>true,	
	));
}
add_action( 'init', 'embryo_custom_post' );


function embryo_style_script(){
    //style sheet adding function
 	wp_register_style( 'zerogrid', get_template_directory_uri() . '/css/zerogrid.css' );
 	wp_register_style( 'style', get_template_directory_uri() . '/css/style.css' );
 	wp_register_style( 'responsive', get_template_directory_uri() . '/css/responsive.css');
 	 
	wp_enqueue_style( 'zerogrid');
	wp_enqueue_style( 'style');
	wp_enqueue_style( 'responsive');
	//js adding function
 	wp_register_script( 'jquery', get_template_directory_uri() . '/js/jquery.min.js');
    wp_enqueue_script('jquery');
    
}
add_action('wp_enqueue_scripts','embryo_style_script'); 

//widget register

function widget_embryo(){
register_sidebar( array(
		'name'          => __( 'sidebar Widget Area', 'squadfee' ),
		'id'            => 'ls',
		'description'   => __( 'Appears in the footer section of the site.', 'squadfee' ),
		'before_widget' => '<div class="wrap-col"><div class="box">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<div class="heading"><h2>',
		'after_title'   => '</div></h2> ',
	) );
	
register_sidebar( array(
		'name'          => __( 'Footer sidebar Widget Area', 'squadfee' ),
		'id'            => 'fs',
		'description'   => __( 'Appears in the footer section of the site.', 'squadfee' ),
		'before_widget' => '<div class="row"><div class="col-1-3"><div class="wrap-col"><div class="box">',
		'after_widget'  => '</div></div></div></div>',
		'before_title'  => '<div class="heading"><h2>',
		'after_title'   => '</h2></div><div class="content">',
	) );
}
add_action( 'widgets_init', 'widget_embryo' );   
?>
<footer>
	<div class="wrap-footer zerogrid">
		<?php dynamic_sidebar('fs');?>
	</div>
	<div class="copyright">
					<?php
					$logo = new WP_query(array(
						'post_type'=>'cp',
						'posts_per_page'=>1
					));
				?>
				<?php while($logo->have_posts()):$logo->the_post();?>
					<?php the_content();?>
				<?php endwhile;?>

		 
	</div>
	<?php wp_footer();?>
</footer>
</body>
</html>
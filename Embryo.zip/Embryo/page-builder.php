<?php get_header();?>
<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block">
			<?php while(have_posts):the_post();?>
			    
			<?php?> 
		</div>
	</div>
</section>
<!--------------Footer--------------->
<?php get_footer();?>